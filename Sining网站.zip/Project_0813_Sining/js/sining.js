var carousel, playindex = 0;
window.onload = function() {
	initCarousel();
	initNavbar();
	initMain && initMain();
	carouselAnimate();

	var top = document.documentElement.scrollTop || document.body.scrollTop;
	var tbtn = document.getElementById("totop");
	tbtn.onclick = function() {
		backToTopTween();
	}
	if (top < 100) {
		tbtn.style.opacity = 0;
	}

	window.onresize = function() { //响应式
		initCarousel();
		initNavbar();
		initMain && initMain();
	}
}



function initCarousel() { //初始化滚屏大图高度
	carousel = document.getElementById("carousel_box");
	var img = carousel.getElementsByTagName("img")[0];
	carousel.style.height = img.offsetHeight + "px";
	//滚图导航
	carousel.obtn = document.getElementById("bottom_nav");
}

function initNavbar() {
	var dw = document.documentElement.clientWidth;
	var ul = document.getElementById("nav_ul");
	var li = ul.getElementsByTagName("li");
	for (var i = 0; i < li.length - 2; i++) {
		li[i].style.display = "block";
	}
	li[li.length - 1].style.display = "none";
	var dm = document.getElementById("dropdown");
	dm.innerHTML = "";
	var w = isPC() ? 751 : 768;
	if (dw < w) {
		document.getElementById("logo").style.marginLeft = "15px";
		return;
	} else {
		var allw = document.getElementById("bs-example-navbar-collapse-1").clientWidth - 30;
		var logow = document.getElementById("logo_a").offsetWidth;
		var navw = allw - logow - 50;
		if (ul.offsetWidth < navw) {
			return;
		} else {
			li[li.length - 1].style.display = "block";
			var i = 2,
				l = li.length;
			while (ul.offsetWidth > navw + 60) {
				li[l - i].style.display = "none";
				i++;
			}

			for (var j = --i; i > 1; i--) {
				var oli = li[l - i].cloneNode(true);
				oli.style.display = "block";
				dm.appendChild(oli);
			}
		}
	}
}


function carouselAnimate() { //开启滚图动画
	for (var i = 0; i < carousel.children.length; i++) {
		if (i == playindex) {
			carousel.children[i].style.opacity = 1;
		} else {
			carousel.children[i].style.opacity = 0;
		}
	}
	carouselTimer();
}

function carouselTimer() { //滚图动画计时器
	clearInterval(carousel.timer);
	var o = 0.02;
	carousel.timer = setTimeout(function() {
		var l = carousel.children.length;
		carousel.obtn.children[playindex].className = "";
		carousel.obtn.children[(playindex + 1) % l].className = "bottom_active";
		var timer = setInterval(function() {
			carousel.children[playindex].style.opacity -= o;
			var _o = parseFloat(carousel.children[(playindex + 1) % l].style.opacity) + o;
			carousel.children[(playindex + 1) % l].style.opacity = _o;
			if (carousel.children[playindex].style.opacity == 0) {
				playindex = (playindex + 1) % l;
				clearInterval(timer);
				carouselTimer();
			}
		}, 30);
	}, 4000);
}

function backToTopTween() {
	var start = document.documentElement.scrollTop || document.body.scrollTop,
		change = -start,
		t = 0,
		endT = 30;
	var timer = setInterval(function() {
		t++;
		if (t >= endT) {
			clearInterval(timer);
		}
		document.documentElement.scrollTop = Tween.Cubic.easeIn(t, start, change, endT); //IE
		document.body.scrollTop = Tween.Cubic.easeIn(t, start, change, endT); //非IE
	}, 30);
	objTween(document.getElementById("totop"), "opacity", "", 1, 0, 10);
}

function isPC() {
	var userAgentInfo = navigator.userAgent;
	var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod", "Safari");
	var flag = true;
	for (var i = 0; i < Agents.length; i++) {
		if (userAgentInfo.indexOf(Agents[i]) > 0) {
			flag = false;
			break;
		}
	}
	return flag;
}

function objTween(obj, type, unit, start, change, endT, cbFn) {
	var start = start,
		change = change - start,
		t = 0,
		endT = endT;
	clearInterval(obj.timer);
	obj.timer = setInterval(function() {
		t++;
		if (t > endT) {
			clearInterval(obj.timer);
			cbFn && cbFn();
			return;
		}
		obj.style[type] = Tween.Sine.easeIn(t, start, change, endT) + unit;
	}, 30)
}


function arrTween(obj, tarr, endT) {
	var t = 0;
	clearInterval(obj.timer);
	obj.timer = setInterval(function() {
		t++;
		if (t > endT) {
			clearInterval(obj.timer);
			return;
		}
		for (var i = 0; i < tarr.length; i++) {
			var j = tarr[i];
			obj.style[j.type] = Tween.Expo.easeIn(t, j.start, j.change, endT) + j.unit;
		}
	}, 30)
}


function wheelFn(obj, succFn) {
	if (window.navigator.userAgent.indexOf("Firefox") != -1) {
		obj.addEventListener("DOMMouseScroll", fn, false);
	} else {
		obj.onmousewheel = fn;
	}

	function fn(e) {
		var e = e || window.event;
		var down = true;
		if (e.detail) {
			down = e.detail > 0;
		} else {
			down = e.wheelDelta < 0;
		}
		succFn.call(obj, e, down); //可返回事件e进行后续处理
		if (e.preventDefault) {
			e.preventDefault();
		}
		return false;
	}
}