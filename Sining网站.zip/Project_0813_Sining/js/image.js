function initMain() {
	initImageNav();
	initImageShow(0);

	var topbol = false;
	wheelFn(document, function(e, down) {
		var top = document.documentElement.scrollTop || document.body.scrollTop;
		var h = document.body.offsetHeight;
		var fh = h - document.getElementById("footer").offsetHeight - document.documentElement.clientHeight - 200;
		console.log(fh);
		if (down) {
			if (top < fh) {
				topbol = false;
			}
			if (top > fh && !topbol) {
				totop.style.display = "block";
				objTween(document.getElementById("totop"), "opacity", "", 0, 1, 10);
				topbol = true;
			}
			document.documentElement.scrollTop += 100;
			document.body.scrollTop += 100;
		} else {
			if (top - 100 < fh && topbol) {
				totop.style.display = "none";
				objTween(document.getElementById("totop"), "opacity", "", 1, 0, 10);
				topbol = false;
			}
			document.documentElement.scrollTop -= 100;
			document.body.scrollTop -= 100;
		}
	});
}

function initImageNav() {
	var nav = document.getElementById("image_nav");
	var _odiv = nav.children[0];
	var _oimg = _odiv.getElementsByTagName("img")[0];
	nav.onclick = function(e) {
		var e = e || window.event;
		var odiv = e.target;
		for (var i = 0; i < nav.children.length; i++) {
			if (odiv == nav.children[i]) {
				var oimg = odiv.getElementsByTagName("img")[0];
				_odiv.className = "";
				_oimg.style.display = "none";
				odiv.className = "image_nav_active";
				oimg.style.display = "block";
				_odiv = odiv;
				_oimg = oimg;
				initImageShow(i);
			}
		}
	}
}

function initImageShow(num) {
	var show = document.getElementById("image_show");
	show.innerHTML = "";
	if (num == 0) {
		var ddc = document.getElementById("ddc_save");
		for (var i = 0; i < ddc.children.length; i++) {
			addImageShow(i);
		}
	} else {
		addImageShow(num - 1);
	}

}

function addImageShow(num) {
	var show = document.getElementById("image_show");
	var ddc = document.getElementById("ddc_save");
	var save = ddc.children[num];
	for (var i = 0; i < save.children.length; i++) {
		var img = save.children[i];
		var ourl = img.getAttribute("data-url"),
			osrc = img.getAttribute("data-src");
		var odiv = createDiv(ourl, osrc);
		show.appendChild(odiv);
		odiv.onclick = function() {
			var url = this.getAttribute("data-url");
			window.open(url);
		}
		odiv.onmouseenter = function() {
			this.children[2].style.display = "block";
		}
		odiv.onmouseleave = function() {
			this.children[2].style.display = "none";
		}
	}
}

function createDiv(ourl, osrc) {
	var div = document.createElement("div");
	div.className = "col-lg-6 col-md-6 image_block";
	div.setAttribute("data-url", ourl);

	var img = document.createElement("img");
	img.src = osrc;
	img.className = "img";
	div.appendChild(img);

	var odiv = document.createElement("div");
	odiv.className = "image_btn";
	img = document.createElement("img");
	img.src = "img/play.png";
	odiv.appendChild(img);
	div.appendChild(odiv);

	odiv = document.createElement("div");
	odiv.className = "shandow";
	div.appendChild(odiv);

	return div;
}