function initMain() {
	var header = document.getElementById("header");
	var main = document.getElementById("main");
	var dh = document.documentElement.clientHeight,
		dw = document.documentElement.clientWidth;
	if (dw > 992) {
		var h = header.offsetHeight;
		for (var i = 0; i < main.children.length; i++) {
			main.children[i].style.height = h + "px";
		}
		initMainServer();
		initMainAbout();
		initMainShow();

		wheelFn(document, function(e, down) {
			var arr = [0, h];
			for (var i = 0; i < main.children.length; i++) {
				arr[i + 2] = arr[i + 1] + main.children[i].clientHeight;
			}
			var top = document.documentElement.scrollTop || document.body.scrollTop;
			if (down) {
				var i;
				for (i = 1; i < arr.length; i++) {
					if (top < arr[i]) {
						break;
					}
				}
				wheelDown(i, top, arr[i] - top);
			} else {
				var i;
				for (i = arr.length - 1; i >= 0; i--) {
					if (top > arr[i]) {
						break;
					}
				}
				var m = top - arr[i] == 0 ? arr[i - 1] - top : arr[i] - top;
				wheelUp(i, top, m);
			}
		});
	}

}


function initMainServer() {
	var server = document.getElementById("server");
	var h = server.children[0].offsetHeight + server.children[1].offsetHeight;
	var _h = server.offsetHeight - h;
	server.children[0].style.paddingTop = _h * 0.35 + "px";
	server.children[1].style.paddingBottom = _h * 0.65 + "px";
}

function initMainAbout(main) {
	var about = document.getElementById("about");
	var h = about.children[0].offsetHeight > about.children[1].offsetHeight ? about.children[0].offsetHeight : about.children[1].offsetHeight;
	h = about.clientHeight - h;
	about.style.paddingTop = h / 2 + "px";
	about.style.paddingBottom = h / 2 + "px";
}

function initMainShow() {
	var show = document.getElementById("show");
	for (var i = 0; i < show.children.length; i++) {
		var obj = show.children[i].children[1].children[0];
		obj.parentNode.style.lineHeight = obj.offsetHeight + "px";
		obj.onmouseenter = function() {
			var t = this.offsetTop,
				h = this.offsetHeight,
				w = this.offsetWidth;
			var toh = t * 2 - 40;
			var pt = this.parentNode.parentNode.clientHeight;
			var pw = this.parentNode.parentNode.clientWidth;
			console.log(pt + "||" + pw);
			obj = this.parentNode;
			obj.style.top = (pt * 0.04375) + pt * 0.17 + "px";
			obj.style.height = pt - (pt * 0.0875) + "px";
			obj.style.width = pw - 30 + "px";
			obj.setAttribute("data-lh", obj.style.lineHeight);
			obj.style.lineHeight = obj.style.height;
			obj.style.color = "#cfdb00";
			this.children[0].children[0].innerHTML += "&gt;&gt;";;
		}
		obj.onmouseout = function() {
			var obj = this.parentNode;
			obj.setAttribute("style", "");
			obj.style.lineHeight = obj.getAttribute("data-lh");
			var s = this.children[0].children[0].innerText;
			s = s.substr(0, s.length - 2);
			this.children[0].children[0].innerText = s;
		}
	}
}




var animatebol_1 = true,
	animatebol_2 = true;

function wheelDown(i, top, m) {
	scrollTween(top, m);
	if (i == 1 && animatebol_1) {
		var obj = document.getElementById("project");
		animateT(obj);
		animatebol_1 = false;
	}
	if (i == 2 && animatebol_2) {
		var obj = document.getElementById("about");
		animateT(obj);
		animatebol_2 = false;
	}
	if (i == 3) {
		totop.style.display = "block";
		objTween(document.getElementById("totop"), "opacity", "", 0, 1, 10);
	}
}

function wheelUp(i, top, m) {
	scrollTween(top, m);
	if (i == 0) {
		totop.style.display = "none";
		objTween(document.getElementById("totop"), "opacity", "", 1, 0, 10);
	}
}

function animateT(obj) {
	setTimeout(function() {
		for (var i = 0; i < obj.children.length; i++) {
			var o = obj.children[i];
			objTween(o, "opacity", "", 0, 1, 40);
		}
	}, 10);
}


var stimer;

function scrollTween(start, change) {
	var start = start,
		change = change,
		t = 0,
		endT = 10;
	clearInterval(stimer);
	stimer = setInterval(function() {
		t++;
		if (t >= endT) {
			clearInterval(stimer);
		}
		document.documentElement.scrollTop = Tween.Cubic.easeIn(t, start, change, endT); //IE
		document.body.scrollTop = Tween.Cubic.easeIn(t, start, change, endT); //非IE
	}, 30);
}

