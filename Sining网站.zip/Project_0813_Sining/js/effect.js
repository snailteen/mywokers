function initMain() {
	initEffectNav();
	initEffectImage(0);

	var topbol = false;
	wheelFn(document, function(e, down) {
		var top = document.documentElement.scrollTop || document.body.scrollTop;
		var h = document.body.offsetHeight;
		var fh = h - document.getElementById("footer").offsetHeight - document.documentElement.clientHeight - 200;
		var totop = document.getElementById("totop");
		if (down) {
			if (top > fh - 50) {
				loadImage();
			}
			if (top < fh) {
				topbol = false;
			}
			if (top > fh && !topbol) {
				totop.style.display = "block";
				objTween(totop, "opacity", "", 0, 1, 10);
				topbol = true;
			}
			document.documentElement.scrollTop += 100;
			document.body.scrollTop += 100;
		} else {
			if (top - 100 < fh && topbol) {
				totop.style.display = "none";
				objTween(totop, "opacity", "", 1, 0, 10);
				topbol = false;
			}
			document.documentElement.scrollTop -= 100;
			document.body.scrollTop -= 100;
		}
	});
}

function initEffectNav() {
	var nav = document.getElementById("effect_nav");
	var _odiv = nav.children[0];
	var _oimg = _odiv.getElementsByTagName("img")[0];
	nav.onclick = function(e) {
		var e = e || window.event;
		var odiv = e.target;
		for (var i = 0; i < nav.children.length; i++) {
			if (odiv == nav.children[i]) {
				var oimg = odiv.getElementsByTagName("img")[0];
				_odiv.className = "";
				_oimg.style.display = "none";
				odiv.className = "effect_nav_active";
				oimg.style.display = "block";
				_odiv = odiv;
				_oimg = oimg;
				initEffectImage(i);
			}
		}
	}
}

var imgw;
var arr_t;

function initEffectImage(num) {
	var show = document.getElementById("effect_show");
	show.innerHTML = "";
	var w = show.clientWidth;
	var imgn = parseInt(w / 310);
	imgn = imgn == 0 ? 1 : imgn;
	imgw = parseInt(w / imgn) - 10;
	arr_t = new Array(imgn);
	for (var i = 0; i < arr_t.length; i++) {
		arr_t[i] = 0;
	}
	count = 0;

	if (num == 0) {
		var ddc = document.getElementById("ddc_save");
		for (var i = 0; i < ddc.children.length; i++) {
			addEffectShow(i);
		}
		loadImage();
	} else {
		addEffectShow(num - 1);
		loadImage();
	}
}

function addEffectShow(num) {
	var show = document.getElementById("effect_show");
	var ddc = document.getElementById("ddc_save");
	var save = ddc.children[num];

	for (var i = 0; i < save.children.length; i++) {
		var obj = save.children[i];
		var osrc = obj.getAttribute("data-src");
		var odiv = createDiv(osrc);
		odiv.style.width = imgw + "px";
		odiv.style.display = "none";
		show.appendChild(odiv);
	}
}

function createDiv(osrc) {
	var div = document.createElement("div");
	div.className = "effect_img";

	var img = document.createElement("img");
	img.setAttribute("data-src",osrc);
	img.className = "img";
	div.appendChild(img);

	var odiv = document.createElement("div");
	odiv.className = "effect_btn";
	img = document.createElement("img");
	img.src = "img/e_1.png";
	odiv.appendChild(img);
	div.appendChild(odiv);

	var odiv = document.createElement("div");
	odiv.className = "shandow";
	div.appendChild(odiv);

	return div;
}

var count = 0;

function loadImage() {
	var show = document.getElementById("effect_show");
	var count_num = count;
	for (var i = count; i < show.children.length; i++) {
		if (i == count + 20) {
			break;
		}
		var obj = show.children[i];
		obj.children[0].src = obj.children[0].getAttribute("data-src");
		obj.children[0].onload = function() {
			var obj = this.parentNode;
			obj.style.display = "block";
			if (count_num == count + 19 || count_num == show.children.length - 1) {
				moveImage();
				return;
			}
			count_num++;
		}

		obj.onmouseenter = function() {
			this.children[1].style.display = "block";
			this.children[2].style.display = "block";
		}
		obj.onmouseleave = function() {
			this.children[1].style.display = "none";
			this.children[2].style.display = "none";
		}
		
		obj.onclick = function(){
			this.children[1].style.display = "none";
			this.children[2].style.display = "none";
			var totop = document.getElementById("totop");
			totop.style.display = "none";
			var big = document.getElementById("show_big_img");
			big.style.display = "block";
			big.children[0].src = this.children[0].src;
			var w = this.children[0].offsetWidth,
			h =  this.children[0].offsetHeight;
			big.children[0].style.height = "90%"
			if(w>h){
			}else{
			}
			
			big.onclick = function(){
				this.style.display = "none";
			}
		}
	}
}

function moveImage() {
	var show = document.getElementById("effect_show");
	for (var i = count; i < show.children.length; i++) {
		if (i == count + 20) {
			break;
		}
		var obj = show.children[i];
		var hi = findMin(arr_t);
		obj.style.left = hi * (imgw + 10) + "px";
		obj.style.top = arr_t[hi] + "px";
		arr_t[hi] += (10 + obj.offsetHeight);
		show.style.height = arr_t[findMax(arr_t)] + 50 + "px";
	}
	count += 20;
}




function findMin(arr) {
	var min = 0;
	for (var i = 1; i < arr.length; i++) {
		min = Math.min(arr[min], arr[i]) == arr[min] ? min : i;
	}
	return min;
}

function findMax(arr) {
	var max = 0;
	for (var i = 1; i < arr.length; i++) {
		max = Math.max(arr[max], arr[i]) == arr[max] ? max : i;
	}
	return max;
}