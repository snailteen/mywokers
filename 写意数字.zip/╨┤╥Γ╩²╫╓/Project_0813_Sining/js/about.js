function initMain(){
	
	
	var topbol = false;
	wheelFn(document, function(e, down) {
		var top = document.documentElement.scrollTop || document.body.scrollTop;
		var h = document.body.offsetHeight;
		var fh = h - document.getElementById("footer").offsetHeight - document.documentElement.clientHeight - 200;
		console.log(fh);
		if (down) {
			if(top < fh){
				topbol = false;
			}
			if (top > fh && !topbol) {
				totop.style.display = "block";
				objTween(document.getElementById("totop"), "opacity", "", 0, 1, 10);
				topbol = true;
			}
			document.documentElement.scrollTop += 100;
			document.body.scrollTop += 100;
		} else {
			if (top - 100 < fh && topbol) {
				totop.style.display = "none";
				objTween(document.getElementById("totop"), "opacity", "", 1, 0, 10);
				topbol = false;
			}
			document.documentElement.scrollTop -= 100;
			document.body.scrollTop -= 100;
		}
	});
}
