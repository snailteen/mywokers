function initMain() {

	initShowTabBtn();
	initShowCase();


	var topbol = false;
	wheelFn(document, function(e, down) {
		var top = document.documentElement.scrollTop || document.body.scrollTop;
		var h = document.body.offsetHeight;
		var fh = h - document.getElementById("footer").offsetHeight - document.documentElement.clientHeight - 200;
		if (down) {
			if (top < fh) {
				topbol = false;
			}
			if (top > fh && !topbol) {
				totop.style.display = "block";
				objTween(document.getElementById("totop"), "opacity", "", 0, 1, 10);
				topbol = true;
			}
			document.documentElement.scrollTop += 100;
			document.body.scrollTop += 100;
		} else {
			if (top - 100 < fh && topbol) {
				totop.style.display = "none";
				objTween(document.getElementById("totop"), "opacity", "", 1, 0, 10);
				topbol = false;
			}
			document.documentElement.scrollTop -= 100;
			document.body.scrollTop -= 100;
		}
	});
}


function initShowTabBtn() {
	var btn = document.getElementById("show_tab_btn"),
		cont = document.getElementById("show_tab_cont");
	var obtn = btn.children[0],
		ocont = cont.children[0];
	btn.children[btn.children.length - 1].style.display = "none";
	for (var i = 0; i < btn.children.length - 1; i++) {
		var o = btn.children[i];
		o.index = i;
		o.style.display = "block";
		o.onclick = function() {
			if (this == obtn) {
				return;
			}
			btn.children[btn.children.length - 1].className = "";
			this.className = "btn_active";
			cont.children[this.index].style.display = "block";
			obtn.className = "";
			ocont.style.display = "none";
			obtn = this;
			ocont = cont.children[this.index];
		}
	}

	var allw = btn.clientWidth * 0.96;
	var j = btn.children.length - 1;
	var li = btn.children[btn.children.length - 1];

	if (btn.children[0].offsetWidth * j > allw - 200) {
		li.style.display = "block";
		while (btn.children[0].offsetWidth * j > allw - 200) {
			j--;
		}
		var ul = document.getElementById("tab-dropdown");
		ul.innerHTML = "";

		for (var k = j; k < btn.children.length - 1; k++) {
			var li = btn.children[k].cloneNode(true);
			li.index = btn.children[k].index;
			btn.children[k].style.display = "none";
			ul.appendChild(li);
			li.onclick = function() {
				if (this == obtn) {
					return;
				}
				this.parentNode.parentNode.className = "btn_active";
				for (var i = 0; i < ul.children.length; i++) {
					if (ul.children[i] == this) {
						this.className = "active";
						cont.children[this.index].style.display = "block";
						obtn.className = "";
						ocont.style.display = "none";
						obtn = this;
						ocont = cont.children[this.index];
					} else {
						ul.children[i].className = "";
					}
				}
			}
		}

		if (j == 0) {
			btn.children[btn.children.length - 1].className = "btn_active";
			ul.children[0].className = "active";
			obtn = ul.children[0];
		}


	} else {
		li.style.display = "none";
	}
}


function initShowCase() {
	var ul = document.getElementById("case_left_nav").getElementsByTagName("ul")[0];
	var li = ul.getElementsByTagName("li");
	var _li = li[0];
	

	ul.onclick = function(e) {
		var e = e || window.event;
		if (e.target == _li) {
			return;
		}
		for (var i = 0; i < li.length; i++) {
			if (e.target == li[i]) {
				li[i].className = "active";
				_li.className = "";
				_li = li[i];
				initimg(i);
			}
		}
	}

	initimg(0);
}

function initimg(num) {
	var img = document.getElementById("case_img_show");
	var box = document.getElementById("show_img_box");
	var ddc = document.getElementById("ddc_save");
	box.innerHTML = "";
	var imgarr = ddc.children[num];
	var seimg;
	for (var i = 0; i < imgarr.children.length; i++) {
		var oimg = imgarr.children[i].cloneNode(true);
		box.appendChild(oimg);
		oimg.src = oimg.getAttribute("data-src");
		oimg.onclick = function(){
			this.className = "active";
			seimg.className = "";
			seimg = this;
			img.src = this.getAttribute("data-src");
		}
	}
	var _img = box.children[0];
	box.style.width = (_img.offsetWidth + 20) * box.children.length + "px";
	img.src = _img.getAttribute("data-src");
	_img.className = "active";
	seimg = _img;
}